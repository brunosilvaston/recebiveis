const fs=require('fs');
const h=fs.readFileSync('index.html','utf8');
const code=h.match(/<script>([\s\S]*)<\/script>\s*<\/body>/)[1];
let bloco='';
for(const n of ['MONEY','NUMT']){ const m=code.match(new RegExp('const '+n+'=[^\\n]+','m')); if(m) bloco+=m[0]+'\n'; }
for(const f of ['n2c','n2f','parse','parseUpSeller','parsePedidoOK']){
  const i=code.indexOf('function '+f+'(');
  let d=0,j=code.indexOf('{',i),fim=j;
  for(let k=j;k<code.length;k++){ if(code[k]==='{')d++; else if(code[k]==='}'){d--; if(d===0){fim=k;break;}} }
  bloco+=code.slice(i,fim+1)+'\n';
}
const ctx={}; new Function('ctx',bloco+'\nctx.parse=parse;')(ctx);
const ok=(n,c,x)=>console.log((c?'  ok  ':'FALHA ')+n+(x!==undefined?('  → '+JSON.stringify(x)):''));

console.log('===== ROMANEIO UPSELLER (Nilton.pdf) =====');
const A=ctx.parse(JSON.parse(fs.readFileSync('testes/upseller.json','utf8')),'Nilton.pdf');
ok('reconheceu como upseller',A.origem==='upseller');
ok('pedido 804',A.num==='804',A.num);
ok('data 2026-08-17',A.data==='2026-08-17',A.data);
ok('cliente NILTINHO',A.nome==='NILTINHO',A.nome);
ok('CNPJ 45.338.257/0001-96',A.doc==='45.338.257/0001-96',A.doc);
ok('CEP 31054-477',A.cep==='31054-477',A.cep);
ok('endereço',A.endereco==='PROFESSORA ANA ROSA SOARES PENIDO',A.endereco);
ok('total 10.200,00',A.total===1020000,A.total);
ok('marcado como pago',A.pago===true);
ok('1 item',A.itens.length===1);
ok('desc sem o número colado',A.itens[0].desc==='PELUCIA JESUS RESPIRA',A.itens[0].desc);
ok('SKU',A.itens[0].cod==='JESUSRESPIRA',A.itens[0].cod);
ok('300 × 34,00 = 10.200,00',A.itens[0].qtd*A.itens[0].unit===A.itens[0].total);
ok('observação',/PADROEIRA/.test(A.obs||''),A.obs);

console.log('\n===== PEDIDO PEDIDOOK (1874) — não pode ter quebrado =====');
const B=ctx.parse(JSON.parse(fs.readFileSync('testes/pedidook.json','utf8')),'Pedido Nº 1874.pdf');
ok('reconheceu como pedidook',B.origem==='pedidook');
ok('pedido 1874',B.num==='1874',B.num);
ok('data 2026-07-12',B.data==='2026-07-12',B.data);
ok('cliente SILVASTON LTDA',B.nome==='SILVASTON LTDA',B.nome);
ok('CNPJ',B.doc==='49.602.223/0001-18',B.doc);
ok('fantasia BRIDE',B.fantasia==='BRIDE',B.fantasia);
ok('cidade Guaratinguetá / SP',B.cidade==='Guaratinguetá / SP',B.cidade);
ok('telefone',B.fone==='(11) 3450-8035',B.fone);
ok('total 256.128,00',B.total===25612800,B.total);
ok('3 itens',B.itens.length===3,B.itens.length);
ok('soma dos itens fecha com o total',B.itens.reduce((s,i)=>s+i.total,0)===B.total);
ok('não foi confundido com upseller',B.pago===undefined);
