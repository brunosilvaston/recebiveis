const http=require('http');
const PORTA=+(process.env.PORTA||54321);
const SENHA=process.env.SENHA||'senha123';
const ESTADO=process.env.ESTADO||'/tmp/mock/state.json';
const T={clientes:[],pedidos:[],itens:[],parcelas:[],recebimentos:[],config:[{chave:'versao',valor:'1'}]};
const LOG=[];
function body(req){return new Promise(r=>{let d='';req.on('data',c=>d+=c);req.on('end',()=>r(d));});}
function pk(t){return 'id';}
http.createServer(async(req,res)=>{
  const u=new URL(req.url,'http://x'); const p=u.pathname;
  res.setHeader('Content-Type','application/json');
  res.setHeader('Access-Control-Allow-Origin','*');
  res.setHeader('Access-Control-Allow-Headers','*');
  res.setHeader('Access-Control-Allow-Methods','GET,POST,PUT,DELETE,PATCH,OPTIONS');
  if(req.method==='OPTIONS'){res.writeHead(204);return res.end();}
  const b=await body(req);
  LOG.push(req.method+' '+p+u.search);
  if(p.startsWith('/auth/v1/token')){
    const j=JSON.parse(b||'{}');
    if(u.searchParams.get('grant_type')==='password'){
      if(j.password!==SENHA&&j.password!=='prov123'){res.writeHead(400);return res.end(JSON.stringify({error_description:'Invalid login credentials'}));}
      LOG.push('LOGIN_EMAIL='+j.email);
      res.writeHead(200);return res.end(JSON.stringify({access_token:'tok1',refresh_token:'ref1',expires_in:3600,user:{email:j.email}}));
    }
    res.writeHead(200);return res.end(JSON.stringify({access_token:'tok2',refresh_token:'ref2',expires_in:3600}));
  }
  if(p==='/auth/v1/user'&&req.method==='PUT'){
    if((req.headers.authorization||'')!=='Bearer conv123'&&(req.headers.authorization||'').indexOf('Bearer tok')<0){res.writeHead(401);return res.end('{}');}
    const j=JSON.parse(b||'{}');
    if(!j.password||j.password.length<6){res.writeHead(422);return res.end(JSON.stringify({msg:'Password should be at least 6 characters'}));}
    res.writeHead(200);return res.end(JSON.stringify({id:'u1',email:'abou@mazen.com'}));
  }
  if(p==='/auth/v1/recover'){ res.writeHead(200); return res.end('{}'); }
  if(p.startsWith('/rest/v1/')){
    if(['Bearer tok1','Bearer tok2','Bearer conv123'].indexOf(req.headers.authorization||'')<0){res.writeHead(401);return res.end('{}');}
    const tab=p.split('/')[3];
    if(!T[tab]){res.writeHead(404);return res.end(JSON.stringify({message:'relation does not exist'}));}
    if(req.method==='GET'){
      let rows=T[tab];
      const q=[...u.searchParams.entries()].find(([k])=>k!=='select'&&k!=='order');
      if(q&&String(q[1]).startsWith('eq.')){const v=decodeURIComponent(q[1].slice(3));rows=rows.filter(x=>String(x[q[0]])===v);}
      res.writeHead(200);return res.end(JSON.stringify(rows));}
    if(req.method==='POST'){
      const rows=JSON.parse(b); const k=tab==='config'?'chave':'id';
      rows.forEach(r=>{const i=T[tab].findIndex(x=>x[k]===r[k]); if(i>=0)T[tab][i]=Object.assign({},T[tab][i],r); else T[tab].push(r);});
      if(tab!=='config'){const c=T.config.find(x=>x.chave==='versao'); if(c) c.valor=String(Date.now());}
      res.writeHead(201);return res.end('');
    }
    if(req.method==='DELETE'){
      const q=[...u.searchParams.entries()].find(([k])=>k!=='select');
      if(q){const[col,val]=q;
        if(val.startsWith('eq.')){const v=decodeURIComponent(val.slice(3));T[tab]=T[tab].filter(x=>String(x[col])!==v);}
        else if(val.startsWith('in.')){const vs=val.slice(4,-1).split(',').map(decodeURIComponent);T[tab]=T[tab].filter(x=>!vs.includes(String(x[col])));}
      }
      res.writeHead(204);return res.end('');
    }
  }
  if(p.startsWith('/storage/v1/object/')){res.writeHead(200);return res.end('{}');}
  res.writeHead(404);res.end('{}');
}).listen(PORTA,()=>console.log('mock on 54321'));
process.on('SIGTERM',()=>{require('fs').writeFileSync(ESTADO,JSON.stringify({T,LOG},null,1));process.exit(0);});
setInterval(()=>require('fs').writeFileSync(ESTADO,JSON.stringify({T,LOG},null,1)),500);
