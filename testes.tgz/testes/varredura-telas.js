const {chromium}=require('playwright');
(async()=>{
  const b=await chromium.launch();
  const pg=await b.newPage({viewport:{width:1440,height:960}});
  const err=[];
  pg.on('pageerror',e=>err.push('PAGEERROR: '+e.message));
  pg.on('console',m=>{ if(m.type()==='error'&&!/ERR_|Failed to load resource/.test(m.text())) err.push('CONSOLE: '+m.text()); });
  await pg.goto('file://'+process.cwd()+'/index.html');
  await pg.evaluate(()=>localStorage.clear());
  await pg.reload(); await pg.waitForTimeout(800);
  await pg.evaluate(()=>usarLocal()); await pg.waitForTimeout(400);

  // dados de exemplo cobrindo tudo
  await pg.evaluate(()=>{
    DB={cfg:{empresa:'TESTE FUMACA'},clientes:[
      {id:'c1',nome:'CLIENTE UM',fantasia:'UM',doc:'11.111.111/0001-11',cidade:'Santos / SP',fone:'(13) 1111-1111',
       email:'a@b.c',ie:'123',contato:'Ana',endereco:'Rua A, 1',bairro:'Centro',cep:'11000-000',transp:'TRANSP',prazo:'30/60',limite:1000000,obs:'obs'},
      {id:'c2',nome:'CLIENTE DOIS'}],
      pedidos:[
      {id:'p1',num:'1',data:'2026-07-01',clienteId:'c1',total:300000,cond:'3x',desc:5000,
       itens:[{cod:'A1',desc:'PRODUTO A',un:'PC',qtd:10,unit:10000,total:100000}],
       parcelas:[
        {venc:'2026-06-01',valor:100000,pagos:[{data:'2026-06-05',valor:100000,forma:'PIX',obs:'ok',comp:{nome:'c.jpg',url:'#',dados:'#'}}]},
        {venc:'2026-09-01',valor:100000,pagos:[{data:'2026-08-01',valor:40000,forma:'Boleto'}]},
        {venc:'2026-12-01',valor:100000,pagos:[]}]},
      {id:'p2',num:'2',data:'2026-08-01',clienteId:'c2',total:50000,itens:[],parcelas:[{venc:'2026-08-15',valor:50000,pagos:[]}]}]};
    save(); renderAll();
  });
  await pg.waitForTimeout(600);

  const passos=[
    ['Visão Geral', async()=>{ await pg.evaluate(()=>go('visao')); }],
    ['filtro: este mês', async()=>{ await pg.click('#pa-mes'); }],
    ['filtro: mês passado', async()=>{ await pg.click('#pa-ant'); }],
    ['filtro: 90 dias', async()=>{ await pg.click('#pa-90'); }],
    ['filtro: este ano', async()=>{ await pg.click('#pa-ano'); }],
    ['filtro: tudo', async()=>{ await pg.click('#pa-tudo'); }],
    ['A Receber', async()=>{ await pg.evaluate(()=>go('receber')); }],
    ['filtrar vencidos', async()=>{ await pg.selectOption('#fSt','vencido'); await pg.selectOption('#fSt',''); }],
    ['Clientes', async()=>{ await pg.evaluate(()=>go('clientes')); }],
    ['período em Clientes', async()=>{ await pg.click('#atCli a:nth-child(2)'); await pg.click('#atCli a:nth-child(1)'); }],
    ['busca em Clientes', async()=>{ await pg.fill('#cfBusca','UM'); await pg.fill('#cfBusca',''); }],
    ['ficha do cliente', async()=>{ await pg.evaluate(()=>fichaCliente('c1')); }],
    ['aba histórico', async()=>{ await pg.evaluate(()=>fichaCliente('c1','hist')); }],
    ['editar cadastro', async()=>{ await pg.evaluate(()=>abrirCliente('c1')); await pg.waitForTimeout(300); await pg.evaluate(()=>fecharModal()); }],
    ['novo cliente', async()=>{ await pg.evaluate(()=>abrirCliente()); await pg.waitForTimeout(300); await pg.evaluate(()=>fecharModal()); }],
    ['Pedidos', async()=>{ await pg.evaluate(()=>go('pedidos')); }],
    ['período em Pedidos', async()=>{ await pg.click('#atPed a:nth-child(2)'); await pg.click('#atPed a:nth-child(1)'); }],
    ['busca em Pedidos', async()=>{ await pg.fill('#pfBusca','PRODUTO'); await pg.fill('#pfBusca',''); }],
    ['detalhe do pedido', async()=>{ await pg.evaluate(()=>verPedido('p1')); }],
    ['editar pedido', async()=>{ await pg.evaluate(()=>editarPedido('p1')); }],
    ['limpar lançamento', async()=>{ await pg.evaluate(()=>limparNovo()); }],
    ['adicionar produto', async()=>{ await pg.evaluate(()=>{addItem(); itemCalc(0,'qtd','5'); itemCalc(0,'unit','10'); usarTotalItens();}); }],
    ['parcelas: presets', async()=>{ await pg.evaluate(()=>{preset(3,30); preset(1,0); preset(12,30);}); }],
    ['parcelas: add/remover', async()=>{ await pg.evaluate(()=>{addParcela(100000); distribuirResto(100000);}); }],
    ['baixa de parcela', async()=>{ await pg.evaluate(()=>abrirBaixa('p1',2)); await pg.waitForTimeout(300); await pg.evaluate(()=>fecharModal()); }],
    ['ver comprovante', async()=>{ await pg.evaluate(()=>{ try{verComprovante('p1',0,0)}catch(e){} }); }],
    ['extrato impresso', async()=>{ await pg.evaluate(()=>{ const o=window.open; window.open=()=>null; try{imprimirExtrato('c1')}catch(e){} window.open=o; }); }],
    ['exportar CSV', async()=>{ await pg.evaluate(()=>{ const cl=HTMLAnchorElement.prototype.click; HTMLAnchorElement.prototype.click=function(){}; try{exportarCSV()}catch(e){} HTMLAnchorElement.prototype.click=cl; }); }],
    ['exportar XLSX', async()=>{ await pg.evaluate(()=>{ try{exportarXLSX()}catch(e){} }); }],
    ['backup JSON', async()=>{ await pg.evaluate(()=>{ const cl=HTMLAnchorElement.prototype.click; HTMLAnchorElement.prototype.click=function(){}; try{exportarJSON()}catch(e){} HTMLAnchorElement.prototype.click=cl; }); }],
    ['configuração', async()=>{ await pg.evaluate(()=>abrirConfig()); await pg.waitForTimeout(300); await pg.evaluate(()=>fecharModal()); }],
    ['trocar senha', async()=>{ await pg.evaluate(()=>{ try{trocarSenha()}catch(e){} }); await pg.evaluate(()=>fecharModal()); }],
    ['recarregar do banco', async()=>{ await pg.evaluate(()=>{ const c=window.confirm; window.confirm=()=>false; try{recarregarDoBanco()}catch(e){} window.confirm=c; }); }],
    ['Lançar Pedido', async()=>{ await pg.evaluate(()=>go('novo')); }],
  ];
  let falhas=0;
  for(const [nome,fn] of passos){
    const antes=err.length;
    try{ await fn(); await pg.waitForTimeout(220); }
    catch(e){ err.push('AÇÃO "'+nome+'" falhou: '+e.message); }
    const novos=err.slice(antes);
    if(novos.length){ falhas++; console.log('❌ '+nome); novos.forEach(x=>console.log('     '+x)); }
    else console.log('   ok  '+nome);
  }
  console.log('\n=============================');
  console.log(falhas? ('❌ '+falhas+' passo(s) com erro') : '✅ 34 passos sem um único erro de JS');
  await b.close();
})();
